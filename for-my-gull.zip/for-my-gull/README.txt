GULL & RUMI — SIX-PAGE WEBSITE

Files:
index.html       Home
story.html       Our Story
memories.html    Our Memories
letter.html      A Letter for Gull
future.html      Our Future
surprise.html    One Last Surprise
style.css        Shared vintage styling
script.js        Optional synthesized background music and surprise reveal
nav.js           Shared page navigation

PUBLISH WITH GITHUB PAGES:
1. Upload every file and the images folder contents (the images folder is currently an optional place for your own pictures) to the ROOT of your repository.
2. Commit changes to the main branch.
3. Open repository Settings > Pages.
4. Under Build and deployment, choose Deploy from a branch.
5. Select Branch: main and Folder: /(root), then Save.
6. Wait a few minutes. Your site URL will be https://YOUR-USERNAME.github.io/for-my-gull/ .

The pages use a few Unsplash-hosted decorative photographs. Music is a soft synthesized melody and starts only when the visitor presses Play. Replace the stock photos with your own images only if you both want to share them publicly.
